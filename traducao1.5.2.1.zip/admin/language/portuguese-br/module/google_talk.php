<?php
// Heading
$_['heading_title']       = 'Google Talk';

// Text
$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo Google Talk atualizado com sucesso!';
$_['text_content_top']    = 'Conteúdo do Topo';
$_['text_content_bottom'] = 'Conteúdo do Rodapé';
$_['text_column_left']    = 'Coluna da Esquerda';
$_['text_column_right']   = 'Coluna da Direita';

// Entry
$_['entry_code']          = 'Código Google Talk:<br /><span class="help">vá em <a onclick="window.open(\'http://www.google.com/talk/service/badge/New\');"><u>Crie Google Talk chatback badge</u></a> e copie &amp; cole o código gerado na caixa de texto.</span>';
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Posição:';
$_['entry_status']        = 'Situação:';
$_['entry_sort_order']    = 'Ordem:';

// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar o módulo Google Talk!';
$_['error_code']          = 'Codigo obrigatório';
?>