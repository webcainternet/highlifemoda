<?php
// Text
$_['text_title']       = 'Transferência Bancária';
$_['text_instruction'] = 'Instruções para Transferência Bancária';
$_['text_description'] = 'Por favor, transfira o valor total para a seguinte conta bancária:';
$_['text_payment']     = 'Seu pedido será enviado assim que confirmarmos o pagamento.';
?>