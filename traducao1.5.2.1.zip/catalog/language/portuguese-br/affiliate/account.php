<?php
// Heading 
$_['heading_title']        = 'Conta de Afiliado';

// Text
$_['text_account']         = 'Conta';
$_['text_my_account']      = 'Minha conta de afiliado';
$_['text_my_tracking']     = 'Informações de monitoramento';
$_['text_my_transactions'] = 'Minhas Transações';
$_['text_edit']            = 'Alterar informações de conta';
$_['text_password']        = 'Alterar minha senha';
$_['text_payment']         = 'Alterar minhas preferências de pagamento';
$_['text_tracking']        = 'Personalizar código de monitoramento';
$_['text_transaction']     = 'Ver meu histórico de transações';
?>