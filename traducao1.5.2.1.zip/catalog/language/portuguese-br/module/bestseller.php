<?php
// Heading 
$_['heading_title'] = 'Os mais vendidos';

// Text
$_['text_reviews']  = 'Baseado em %s avaliações.'; 
?>