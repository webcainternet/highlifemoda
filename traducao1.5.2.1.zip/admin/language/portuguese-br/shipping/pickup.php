<?php
// Heading
$_['heading_title']    = 'Retirar na Loja';

// Text 
$_['text_shipping']    = 'Frete';
$_['text_success']     = 'Módulo Retirar na Loja atualizado com sucesso!';

// Entry
$_['entry_geo_zone']   = 'Região geográfica:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordenação:';

// Error
$_['error_permission'] = 'Atenção: você não possui permissão para modificar o módulo Retirar na Loja!';
?>