<?php
// Heading
$_['heading_title']		= 'Módulos';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';

// Column
$_['column_name']		= 'Nome do módulo';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar os Módulos!';
?>