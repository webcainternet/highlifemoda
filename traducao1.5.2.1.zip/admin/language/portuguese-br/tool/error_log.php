<?php
// Heading
$_['heading_title'] = 'Registro de erros';

// Text
$_['text_success']  = 'Registro (log) de erros limpo com sucesso!';
?>