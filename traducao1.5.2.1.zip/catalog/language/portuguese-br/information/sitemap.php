<?php
// Heading
$_['heading_title']    = 'Mapa do site';
 
// Text
$_['text_special']     = 'Ofertas especiais';
$_['text_account']     = 'Minha conta';
$_['text_edit']        = 'Informações de conta';
$_['text_password']    = 'Senha';
$_['text_address']     = 'Lista de endereços';
$_['text_history']     = 'Histórico de pedidos';
$_['text_download']    = 'Downloads';
$_['text_cart']        = 'Carrinho de compras';
$_['text_checkout']    = 'Finalização';
$_['text_search']      = 'Busca';
$_['text_information'] = 'Informação';
$_['text_contact']     = 'Contate-nos';
?>
