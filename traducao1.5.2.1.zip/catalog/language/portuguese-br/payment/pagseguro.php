<?php
/**
 * Tradução do modulo no lado do cliente
 *
 * @author ldmotta - ldmotta@gmail.com
 * @link motanet.com.br
 */

$_['text_title']   = 'PagSeguro';
