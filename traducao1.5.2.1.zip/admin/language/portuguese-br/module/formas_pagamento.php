<?php
// Heading
$_['heading_title']		= 'Formas de Pagamento';

// Text
$_['text_module']		= 'Módulos';
$_['text_success']		= 'Módulo Categorias atualizado com sucesso!';
$_['text_left']			= 'Esquerda';
$_['text_right']		= 'Direita';

// Entry
$_['entry_parcelas_vitrine']	= 'QTD Parcelas vitrine:';
$_['entry_valor_minimo']		= 'Valor minimo das parcelas vitrine:';
$_['entry_status']		= 'Situação:';


// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar o módulo Categorias!';
?>

<?php
/*
// Heading
$_['heading_title']    = '<font color="green"><b>Categorias Superfish</b></font>';
$_['heading_title_normal']    = 'Categorias Superfish';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Sucesso: você modificou o módulo Categorias Superfish!';
$_['text_left']        = 'Esquerda';
$_['text_right']       = 'Direita';
$_['text_middletop']        = 'Middle Top';
$_['text_home']             = 'Principal';

// Entry
$_['entry_position']   = 'Posição:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Aviso: Você não tem permissão para modificar o modulo Categorias Superfish!';*/
?>