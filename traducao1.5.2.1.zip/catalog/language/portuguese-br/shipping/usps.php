<?php
// Text
$_['text_title']  = 'Servi�o Postal dos Estados Unidos';
$_['text_weight'] = 'Peso:';
$_['text_eta']    = 'Tempo Estimado:';
?>