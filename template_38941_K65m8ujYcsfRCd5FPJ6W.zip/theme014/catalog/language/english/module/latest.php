<?php
// Heading 
$_['heading_title'] = 'New products';
$_['button_details']          = 'Details';
// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>