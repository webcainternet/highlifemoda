<?php
// Heading 
$_['heading_title'] = 'Sair da Minha Conta';

// Text
$_['text_message']  = '<p>Você saiu de sua conta.</p><p>Se havia itens em seu carrinho eles foram salvos e serão recuperados quando você efetuar o acesso novamente.</p><br />';
$_['text_account']  = 'Cadastro';
$_['text_logout']   = 'Sair';
?>