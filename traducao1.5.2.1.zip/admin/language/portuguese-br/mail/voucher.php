<?php
// Text
$_['text_subject']  = 'Você enviou um vale presente para %s';
$_['text_greeting'] = 'Parabéns, você recebeu um vale presente no valor de %s';
$_['text_from']     = 'Este vale presente foi enviando a você por %s';
$_['text_message']  = 'Com uma mensagem dizendo';
$_['text_redeem']   = 'Para resgatar esse vale-presente, anote o código de resgate, que é <b>%s</ b>, em seguida, clique no link abaixo e coloque no carrinho o produto que você deseja gastar esse vale presente. Você pode digitar o código do vale presente na página do carrinho de compras antes de clicar em finalizar.';
$_['text_footer']   = 'Por favor, responda este e-mail se tiver alguma dúvida.';
?>