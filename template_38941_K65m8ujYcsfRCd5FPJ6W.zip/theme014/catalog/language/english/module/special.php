<?php
// Heading 
$_['heading_title'] = 'Specials';
$_['save_text'] = 'save';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>