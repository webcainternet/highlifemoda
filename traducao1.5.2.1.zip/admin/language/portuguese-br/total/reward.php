<?php
// Heading
$_['heading_title']    = 'Pontos de Fidelidade';

// Text
$_['text_total']       = 'Total do pedido';
$_['text_success']     = 'Pontos de Fidelidade atualizado com sucesso!';


// Entry
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o Pontos de Fidelidade!';
?>