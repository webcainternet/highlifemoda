<?php
// Heading 
$_['heading_title']   = 'Downloads Disponíveis';

// Text
$_['text_account']    = 'Conta';
$_['text_downloads']  = 'Downloads';
$_['text_order']      = 'Identificação de pedido:';
$_['text_date_added'] = 'Adicionado em:';
$_['text_name']       = 'Nome:';
$_['text_remaining']  = 'Downloads restantes:';
$_['text_size']       = 'Tamanho:';
$_['text_empty']      = 'Nenhum pedido de download foi registrado até o momento!';
?>