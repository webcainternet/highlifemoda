<?php
// Heading
$_['heading_title']  = 'Relatório dos produtos vizualizados';

// Text
$_['text_success']   = 'Você resetou o relatório de produtos vizualizados com sucesso!';

// Column
$_['column_name']    = 'Nome do produto';
$_['column_model']   = 'Modelo';
$_['column_viewed']  = 'Visto';
$_['column_percent'] = 'Porcentagem';
?>