<?php
// Text
$_['text_title']       = 'Retirar na loja';
$_['text_description'] = 'Retirar na loja';
?>