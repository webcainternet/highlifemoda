<?php
// Text
$_['text_subject']  = '%s - Nova senha';
$_['text_greeting'] = 'Uma nova senha foi solicitada atavés de %s.';
$_['text_password'] = 'Sua nova senha é:';
?>