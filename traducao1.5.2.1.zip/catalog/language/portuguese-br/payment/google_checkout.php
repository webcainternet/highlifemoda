<?php
// Entry
$_['entry_postcode'] = 'CEP:';
$_['entry_country']  = 'País:';
$_['entry_zone']     = 'Estado:';
?>