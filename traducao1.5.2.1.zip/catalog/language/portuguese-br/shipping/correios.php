<?php
$_['text_41106']  = 'PAC. Entrega: %s dias úteis.';
$_['text_40010']  = 'Sedex. Entrega: %s dias úteis.';
$_['text_40215']  = 'Sedex 10.';
$_['text_40045']  = 'Sedex a Cobrar. Entrega: %s dias úteis. Valor retirada: %s.';

$_['text_title']  = 'Correios';

$_['error_dim'] 			= 'Módulo Correios (Brasil) -> produto com dimensões ou peso inválidos ou não cadastrados: %s';
$_['error_dim_limite'] 		= 'Módulo Correios (Brasil) -> produto com dimensões acima do permitido (%sx%sx%s, CxLxA em cm): %s (%sx%sx%s)';
$_['error_dim_soma'] 		= 'Módulo Correios (Brasil) -> produto com a soma das dimensões acima do limite permitido (%scm): %s (%scm)';
$_['error_peso'] 			= 'Módulo Correios (Brasil) -> produto com o peso acima do permitido (%sKg): %s (%sKg)';

?>