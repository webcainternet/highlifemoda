<?php
// Heading
$_['heading_title']		= 'Finalização do pedido';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';

// Column
$_['column_name']		= 'Total do pedido';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar a Finalização do pedido!';
?>