<?php
// Text
$_['text_subject']		= '%s - Pedido atualizado %s';
$_['text_order']		= 'Pedido Nº:';
$_['text_date_added']	= 'Data da compra:';
$_['text_order_status']	= 'Seu pedido foi atualizado para a seguinte situação:';
$_['text_comment']		= 'Os comentários do seu pedido são:';
$_['text_link']			= 'Para ver o seu pedido, por favor, clique no link abaixo:';
$_['text_footer']		= 'Por favor, responda este e-mail se você tiver qualquer dúvida.';
?>