<?php
// Text
$_['text_title']           = 'Cartão de Crédito/Débito (Web Payment Software)';
$_['text_credit_card']     = 'Detalhes do Cartão de Crédito';
$_['text_wait']            = 'Aguarde...';

// Entry
$_['entry_cc_owner']       = 'Dono do Cartão:';
$_['entry_cc_number']      = 'Número do Cartão:';
$_['entry_cc_expire_date'] = 'Valido Até:';
$_['entry_cc_cvv2']        = 'Código de Segurança do Cartão (CVV2):';
?>