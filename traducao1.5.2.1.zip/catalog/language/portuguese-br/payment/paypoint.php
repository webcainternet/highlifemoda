<?php
// Heading
$_['heading_title']     = 'Obrigado por comprar com %s .... ';

// Text
$_['text_title']        = 'Cartão de Crédito/Débito (PayPoint)';
$_['text_response']     = 'Resposta de PayPoint:';
$_['text_success']      = '... seu pagamento foi recebido com sucesso.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">Aguarde...</span></b> enquanto nós terminamos de processar seu pedido.<br>Se você não for automaticamente redirecionado em 10 segundos, <a href="%s">clique aqui</a>.';
$_['text_failure']      = '... Seu pagamento foi cancelado!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">Aguarde...</span></b><br>Se você não for automaticamente redirecionado em 10 segundos, <a href="%s">clique aqui</a>.';										  
?>