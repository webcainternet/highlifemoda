<?php
// Text
$_['text_subject']  = '%s - Programa de afiliados';
$_['text_welcome']  = 'Obrigado por aderir ao %s Programa de afiliados!';
$_['text_approval'] = 'Sua conta precisa ser aprovada antes de você poder efetuar login. Assim que for aprovado você poderá logar-se usando seu endereço de e-mail e senha ao vistar nossa loja, ou através desse link:';
$_['text_services'] = 'Ao fazer o login, você será capaz de gerar os códigos de monitoramento, acessar pagamentos de comissões, e controlar e editar as informações da conta.';
$_['text_thanks']   = 'Atenciosamente,';
?>