<?php
// Heading
$_['heading_title']       = 'Cor de pedido por status';

// Text
$_['text_module']         = 'Módulos';
$_['text_success']        = 'Módulo "Cor de pedido por status" atualizado com sucesso!';

// Entry
$_['entry_status']        = 'Situação:';


// Error
$_['error_permission']    = 'Atenção: Você não possui permissão para modificar módulo "Cor de pedido por status"!';

?>