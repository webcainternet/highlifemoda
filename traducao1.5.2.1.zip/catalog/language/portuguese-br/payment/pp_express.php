<?php
// Text
$_['text_title'] = 'PayPal Express (incluindo cartão de crédito e débito)';
?>