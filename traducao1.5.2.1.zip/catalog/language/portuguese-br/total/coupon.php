<?php

// Text
$_['text_coupon'] = 'Cupom(%s)';

?>