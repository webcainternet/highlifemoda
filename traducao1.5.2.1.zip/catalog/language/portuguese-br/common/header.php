<?php

// Text
$_['text_home']           = 'Home';
$_['text_wishlist']       = 'Lista de desejos (%s)';
$_['text_shopping_cart']  = 'Carrinho de compras';
$_['text_search']         = 'Busca';
$_['text_welcome']        = 'Seja bem vindo, visitante! Você pode <a href="%s">entrar</a> ou <a href="%s">criar uma conta</a>.';
$_['text_logged']         = 'Você está logado como <a href="%s">%s</a> <b>(</b> <a href="%s">Sair</a> <b>)</b>';
$_['text_account']        = 'Minha conta';
$_['text_checkout']       = 'Finalizar pedido';
?>