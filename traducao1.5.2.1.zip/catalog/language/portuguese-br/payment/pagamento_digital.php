<?php
$_['text_title'] 		= 'Pagamento Digital';
$_['text_information'] 	= 'Ao clicar no botão abaixo, você será redirecionado para o site do Pagamento Digital para efeturar o pagamento. Ao concluir o pagamento você retornará automaticamente para a loja.';
$_['text_wait']         = 'Por favor, aguarde!';
?>