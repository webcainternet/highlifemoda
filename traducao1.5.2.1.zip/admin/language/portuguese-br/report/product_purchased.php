<?php
// Heading
$_['heading_title']     = 'Relatório de compras';

// Text
$_['text_all_status']   = 'Todos os status';

// Column
$_['column_date_start'] = 'Data de início';
$_['column_date_end']   = 'Data de finalização';
$_['column_name']       = 'Nome do produto';
$_['column_model']      = 'Modelo';
$_['column_quantity']   = 'Quantidade';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'Data de início:';
$_['entry_date_end']    = 'Data de finalização:';
$_['entry_status']      = 'Status do pedido:';
?>