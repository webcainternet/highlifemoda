<?php
// Text
$_['text_home']     = 'Home';
$_['text_wishlist'] = 'Wish list <span>(%s)</span>';
$_['text_shopcart']     = 'Shopping cart';
$_['text_items']    = '%s item(s) -<strong> %s</strong>';
$_['text_search']   = 'Search';
$_['text_welcome']  = 'Welcome visitor you can <a href="%s">Create an account</a>';
$_['text_logged']   = 'You are logged in as <a href="%s">%s</a> <b>(</b> <a href="%s">Logout</a> <b>)</b>';
$_['text_account']  = 'My account';
$_['text_checkout'] = 'Checkout';
$_['text_language'] = 'Language';
$_['text_currency'] = 'Currency';
$_['text_welcome1']  = '<a href="%s">login</a>';
$_['text_logged1']   = '<a href="%s">Logout</a>';
?>