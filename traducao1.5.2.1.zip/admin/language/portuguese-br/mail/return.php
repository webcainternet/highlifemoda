<?php
// Text
$_['text_subject']       = '%s - Devolução atualizada %s';
$_['text_return_id']     = 'ID da devolução:';
$_['text_date_added']    = 'Data da devolução:';
$_['text_return_status'] = 'Sua devolução foi atualizada para o seguinte status:';
$_['text_comment']       = 'O comentário dessa devolução é:';
$_['text_footer']        = 'Por favor, responda este e-mail se tiver alguma dúvida.';
?>