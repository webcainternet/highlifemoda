<?php
// Text
$_['text_title']       = 'Frete Personalizado';
$_['text_description'] = 'Valor do frete';
?>