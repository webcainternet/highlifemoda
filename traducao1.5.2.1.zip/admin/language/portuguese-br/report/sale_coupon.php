<?php
// Heading
$_['heading_title']    = 'Relatório de cupons';

// Column
$_['column_name']      = 'Nome do cupom';
$_['column_code']      = 'Código';
$_['column_orders']    = 'Compras';
$_['column_total']     = 'Total';
$_['column_action']    = 'Atividade';

// Entry
$_['entry_date_start'] = 'Data de início:';
$_['entry_date_end']   = 'Data de finalização:';
?>