<?php
// header
$_['heading_title']		= 'Administração';

// Text
$_['text_heading']		= 'Administração';
$_['text_login']		= 'Por favor, digite suas informações.';
$_['text_forgotten'] 	= 'Esqueci minha senha';

// Entry
$_['entry_username']	= 'Seu Usuário:';
$_['entry_password']	= 'Sua Senha:';

// Button
$_['button_login']		= 'Entrar';

// Error
$_['error_login']		= 'Usuário e/ou senha inválido(s).';
$_['error_token']		= 'Token de sessão inválido. Por favor, efetue login novamente.';

?>
