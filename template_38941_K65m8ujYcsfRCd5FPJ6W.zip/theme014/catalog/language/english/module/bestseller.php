<?php
// Heading 
$_['heading_title'] = 'Bestsellers';
$_['off_text'] = 'off';
// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>