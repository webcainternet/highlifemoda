<?php
// Text
$_['text_error'] = 'Informação de página não encontrada!';
?>