<?php
// Text
$_['text_title']       = 'Taxa fixa';
$_['text_description'] = 'Taxa fixa de frete';
?>