<?php
// Heading
$_['heading_title'] = 'P�gina n�o encontrada!';

// Text
$_['text_error']    = 'A p�gina que voc� busca n�o foi encontrada.';
?>