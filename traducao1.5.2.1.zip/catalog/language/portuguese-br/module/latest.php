<?php
// Heading 
$_['heading_title'] = 'Destaques';

// Text
$_['text_reviews']  = 'Baseado em %s avaliações.'; 
?>