<?php
// Heading
$_['heading_title']    = 'Frete Grátis';

// Text 
$_['text_shipping']    = 'Frete';
$_['text_success']     = 'Frete Grátis atualizado com sucesso!';

// Entry
$_['entry_total']      = 'Total:<br /><span class="help">Total da compra requerido para que o frete grátis seja oferecido.</span>';
$_['entry_geo_zone']   = 'Região geografica:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Frete Grátis!';
?>